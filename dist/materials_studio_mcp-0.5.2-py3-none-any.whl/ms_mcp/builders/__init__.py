"""Structure builders."""
