"""Materials Studio output parsers."""
