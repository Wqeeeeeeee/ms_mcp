"""Validation helpers."""
